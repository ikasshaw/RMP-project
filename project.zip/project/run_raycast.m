close all
clear all
addpath("TransformationToolboxFunctions\");
addpath("utilities\");


seeds = [2, 3, 4, 7, 9, 10, 20, 93400];

seed = seeds(end-2);

[A, B, q_init, q_goal, bounds] = createEnvironment('seed', seed, 'numObstacles', 5);%, 'regularRobot', false, 'robotOrientation', 0);

tic
q_path = rayCastPlanner(A, q_init, q_goal, B, bounds, 'considerBounds', true, 'debug', true);
toc

%% Plot the path
[Fa, ~] = plotRobot(q_init, A, "world", true);


plotPath(q_path, Fa, A, B)

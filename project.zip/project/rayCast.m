 % Isaac Shaw
% Robot Motion Planning
% 8/10/2025

function qpath = rayCast(A, q_init, q_goal, B, bounds, options)

    arguments
        A (2, :) double
        q_init (3,1) double
        q_goal (3,1) double
        B cell
        bounds (2, :) double

        options.initialRays (1,1) double = 10
        options.bounceRays (1,1) double {mustBeGreaterThanOrEqual(options.bounceRays, 3)}= 3
        options.maxIter (1,1) double = 100

        options.debug logical = false
        options.plotPath logical = true
        options.plotObstacles logical = true
        options.plotBounds logical = true

        % ---- Planner knobs ----
        % options.debug logical = false
        % options.maxIter (1,1) double = 5000
        % options.stepSize (1,1) double = 0.5
        % options.goalBias (1,1) double = 0.05

        % % ---- Kinematic limits ----
        % options.omegaMax (1,1) double = pi/2
        % options.vMax (1,1) double = 1
        % options.wTheta (1,1) double = 0.5

        % % ---- Collision sampling ----
        % options.numCollisionSteps (1,1) double = 20
        % options.deltaT (1,1) double = 0.1           % reserved (not used; keep for interface)
        % options.considerBounds logical = true

        % ---- Goal capture & finish ----
        options.goalRegionMargin (1,1) double = 1e-3
        options.goalAngleSteps (1,1) double = 36
        options.goalLineSteps (1,1) double = 50
        options.goalRegionNRays (1,1) double = 360

        % % ---- Steering mode ----
        % options.steeringMode (1,:) char {mustBeMember(options.steeringMode, {'dubins','reeds-shepp'})} = 'dubins'
        % % options.steeringMode (1,:) char {mustBeMember(options.steeringMode, {'dubins','reeds-shepp'})} = 'reeds-shepp'
    end

    % --------------------------
    % Input validation
    % --------------------------
    checkQ(q_init); checkQ(q_goal);
    checkVertices(A); checkVertices(bounds);

    if ~inpolygon(q_init(1), q_init(2), bounds(1,:), bounds(2,:)) || ...
       ~inpolygon(q_goal(1), q_goal(2), bounds(1,:), bounds(2,:))
        error('All points must be inside the boundary')
    end

    for i = 1:numel(B)
        checkVertices(B{i});
        if ~all(inpolygon(B{i}(1,:), B{i}(2,:), bounds(1,:), bounds(2,:)))
            error('All obstacle vertices must be inside the boundary')
        end
    end

    % --------------------------
    % Precompute geometry
    % --------------------------
    % Obstacles as polyshape for overlap tests
    obstacles = cell(1, numel(B));
    for i = 1:numel(B)
        obstacles{i} = polyshape(B{i}.', 'Simplify', false);
    end
    % Boundary as polyshape (for plotting & capture rays)
    boundsPolyshape = polyshape(bounds.', 'Simplify', false);

    % Sampling limits for random XY draws
    x_lims = [min(bounds(1,:)), max(bounds(1,:))];
    y_lims = [min(bounds(2,:)), max(bounds(2,:))];

    % Max ray length is diagonal of the bounding box
    maxRayLength = norm([x_lims(2)-x_lims(1), y_lims(2)-y_lims(1)]);

    % --------------------------
    % Goal capture region sizing
    % --------------------------
    % robot_radius: max distance of any body vertex from origin (circumscribed radius);
    % guarantees safe in-place rotation if the circle is entirely collision-free.
    robot_radius = max(vecnorm(A, 2, 1));
    % d_ray: nearest distance from goal XY to any boundary/obstacle along any direction (ray casting).
    d_ray = radialClearance(q_goal(1:2), obstacles, boundsPolyshape, options.goalRegionNRays);
    % r_cap: largest safe circle radius allowing a full in-place spin, with a small margin.
    r_cap = max(0, d_ray - (robot_radius + options.goalRegionMargin));


    % Steps of rayCast alg
    % 1) Generate a set of n random directions and check that these are valid directions for the robot to turn to.
    % 2) For each random direction
    %   a) Get the Cspace configuration for the selected ray orientation
    %   b) cast the ray from the robot's current position in the current random direction
    %   c) Check if the ray hits the goal region or an obstacle
    %   d) If the ray hits the goal region, add the path to a list
    %   e) If the ray hits an obstacle, backup some radius from the collision point and emit a set of new random directions (again checking that the turn to the emission direction is free of a collision) from the collision point and one that is the actual reflection angle.
    %   f) Continue until the ray hits the goal region or a maximum number of iterations
    %   g) If the ray hits the goal region, add the path to a list of successful paths.
    % 3) Loop through the successful paths rays and find intersections with the successful paths.
    % 4) Generate a graph where the intersection points are the nodes and the rays are the edges. (this should include the obstacle and boundary collision points)
    % 5) Use the graph to find the shortest path from the start to the goal
    % 6) Return the path as a sequence of configurations (q) that the robot can follow.
    % 7) If not path is found, return an empty array.
    % --------------------------

    % Initial ray directions
    initialRaysAngles = [atan2(q_goal(2)-q_init(2)), linspace(0, 2*pi, options.initialRays)];

    % Check each angle is valid for the robot to turn to from the current positionand orientation
    validRays = [];
    for angle = initialRaysAngles
        % Check if the robot can turn to the angle from the current position and orientation
        if rotateFree(q_init, angle, A, obstacles, boundsPolyshape, options.considerBounds, options.goalAngleSteps)
            validRays(end+1) = angle;
        end
    end

    % Begin to iterate through the valid angles and cast rays
    qpath = [];


    for angle = validRays

        % Cast the ray from the current position in the current direction
        % Need a function that finds where the ray intersects with the obstacles and boundary
        % and returns the intersection point of collision
        [collPoint, hitGoal] = rayCastCollision(q_init, angle, maxRayLength, A, obstacles, boundsPolyshape, options.considerBounds);

        %         [q_new, traj, isFree] = steer(q_init, [q_goal(1); q_goal(2); angle], options.stepSize, options.vMax, options.omegaMax, A, obstacles, options.numCollisionSteps, [], boundsPolyshape, options.considerBounds, options.steeringMode);

        if ~isFree
            continue;  % Skip this ray if it hits an obstacle
        end

        % Check if the ray hits the goal region
        if norm(q_new(1:2) - q_goal(1:2)) <= r_cap
            % Add the path to the list of successful paths
            qpath = [qpath, q_new];
            if options.plotPath
                plotPath(q_new, A, B, boundsPolyshape);
            end
            continue;
        end

        % If the ray does not hit the goal region, check for collisions and bounce
        for iter = 1:options.maxIter
            % Get the collision point and bounce direction
            collisionPoint = traj(:, end);
            bounceAngle = wrapToPi(angle + pi);  % Reflect the angle

            % Emit new rays from the collision point in random directions
            newRaysAngles = linspace(0, 2*pi, options.bounceRays) + bounceAngle;

            for newAngle = newRaysAngles
                if rotateFree(collisionPoint, newAngle, A, obstacles, boundsPolyshape, options.considerBounds, options.goalAngleSteps)
                    [q_new_bounce, traj_bounce, isFreeBounce] = steer(collisionPoint, [q_goal(1); q_goal(2); newAngle], options.stepSize, options.vMax, options.omegaMax, A, obstacles, options.numCollisionSteps, [], boundsPolyshape, options.considerBounds, options.steeringMode);
                    if isFreeBounce && norm(q_new_bounce(1:2) - q_goal(1:2)) <= r_cap
                        qpath = [qpath, q_new_bounce];
                        if options.plotPath
                            plotPath(q_new_bounce, A, B, boundsPolyshape);
                        end
                        break;  % Exit inner loop on success
                    end
                end
            end

            if ~isempty(qpath)
                break;  %


    % Initialize the path with the start configuration
    qpath = q_init;

    % Initialize the current configuration
    q_current = q_init;

    % Initialize the goal region as a circle around the goal
    goalRegionRadius = options.goalRegionMargin;
    goalRegion = polyshape(q_goal(1) + goalRegionRadius * cos(linspace(0, 2*pi, 100)), ...
                           q_goal(2) + goalRegionRadius * sin(linspace(0, 2*pi, 100)));
    % Initialize the number of rays to cast
    nRays = options.goalRegionNRays;


end

% ======================================================================
% Distance & geometry helpers
% ======================================================================

% Lets write the ray cast collision function that casts a ray from the current position in the given direction and returns the collision point and whether it hit the goal region or an obstacle.
function [collPoint, hitGoal] = rayCastCollision(origin, angle, maxRayLength, A, obstacles, boundsPolyshape, considerBounds)

    arguments
        origin (3,1) double  % [x; y; theta]
        angle (1,1) double   % angle in radians
        maxRayLength (1,1) double
        A (2,:) double
        obstacles cell
        boundsPolyshape polyshape
        considerBounds logical = true
    end

    % rayCastCollision
    % Cast a ray from q_init in the given angle and return the collision point and whether it hit the goal region or an obstacle.
    % Returns:
    %   collPoint: the point of collision with an obstacle or boundary
    %   hitGoal: true if the ray hits the goal region, false otherwise

    % Get a polyshape that is the union of all Cspace obstacles and the boundary
    % (for fast intersection checks)
    
    % Ray direction vector
    u = [cos(angle); sin(angle)];
    
    % Ray end point
    p_end = origin(1:2) + maxRayLength * u;
    
    % Check for intersection with obstacles and boundary
    collPoint = [];
    hitGoal = false;

    if considerBounds
        allIntersectionPoly = union(obstacles{:}, boundsPolyshape);
    else
        allIntersectionPoly = union(obstacles);
    end

    % Check for first intersection with the allIntersectionPoly
    [collPoint, ~] = intersect(polyshape([origin(1); p_end(1)], [origin(2); p_end(2)]), allIntersectionPoly, 'Union', true);

    if isempty(collPoint)
        return;  % No collision found, return empty
    end

    % Check if the collision point is within the goal region radius
    if norm(collPoint - q_goal(1:2)) <= options.goalRegionMargin
        hitGoal = true;
    end

end



function dmin = radialClearance(p, obstacles, boundsPoly, nRays)
    % radialClearance
    % Cast nRays from point p in [0,2π) and return the nearest distance to
    % any polygon edge (obstacles or boundary). Used to size the capture region.
    phis = linspace(0, 2*pi, nRays+1); phis(end) = [];
    dmin = inf;
    polys = [obstacles, {boundsPoly}];
    for phi = phis
        u = [cos(phi); sin(phi)];
        d_ray = inf;
        for k = 1:numel(polys)
            V = polys{k}.Vertices.'; % 2xK
            K = size(V,2);
            for i = 1:K
                a = V(:,i);
                b = V(:,mod(i,K)+1);
                t = raySegIntersectDist(p, u, a, b);
                if ~isnan(t)
                    d_ray = min(d_ray, t);
                end
            end
        end
        dmin = min(dmin, d_ray);
    end
    if isinf(dmin), dmin = 0; end
end

function t = raySegIntersectDist(p, u, a, b)
    % raySegIntersectDist
    % Solve p + t u = a + s (b-a) with t>=0 and s∈[0,1] via a 2x2 system.
    % Returns the smallest nonzero t (distance along ray) or NaN if no hit.
    v = b - a;
    M = [u, -v];
    rhs = a - p;
    detM = u(1)*(-v(2)) - u(2)*(-v(1));
    if abs(detM) < 1e-12, t = NaN; return; end
    sol = M \ rhs;  t = sol(1); s = sol(2);
    if t >= 0 && s >= 0 && s <= 1
        if t < 1e-12, t = NaN; end  % ignore grazing at the start point
    else
        t = NaN;
    end
end

% ======================================================================
% RRT helpers
% ======================================================================

function d = configDist(q1, q2, wTheta)
    % configDist
    % Weighted metric on SE(2): Euclidean XY + wTheta * |wrapped Δθ|
    dx = q1(1) - q2(1); dy = q1(2) - q2(2);
    dtheta = wrapToPi(q1(3) - q2(3));
    d = sqrt(dx^2 + dy^2) + wTheta * abs(dtheta);
end

% function [q_new, traj, isFree] = steer(q_from, q_to, stepSize, vMax, omegaMax, ...
%                                        A, obstacles, numSteps, ~, ...
%                                        bounds, considerBounds, steeringMode)
%     % steer
%     % Take ONE curvature-bounded step toward q_to.
%     %   • Dubins mode: forward-only; if target is mostly behind, rotate-in-place first.
%     %   • Reeds–Shepp mode: may choose reverse if that reduces error.
%     % Motion is integrated in closed form and sampled numSteps times for collisions.

%     % Direction & heading error
%     dx = q_to(1)-q_from(1); dy = q_to(2)-q_from(2);
%     d = hypot(dx,dy);
%     alpha = atan2(dy,dx);
%     e = wrapToPi(alpha - q_from(3));  % signed shortest heading error

%     if d < 1e-6
%         % Orientation-only target: do a bounded in-place rotation
%         dtheta = wrapToPi(q_to(3)-q_from(3));
%         if abs(dtheta) < 1e-6
%             q_new = q_from; traj = q_from; isFree = true; return;
%         end
%         omega = sign(dtheta)*omegaMax; v = 0; t = abs(dtheta)/max(abs(omega),eps);
%     else
%         switch steeringMode
%             case 'reeds-shepp'
%                 % May reverse if goal is "behind"
%                 if cos(e) >= 0
%                     v = vMax;
%                 else
%                     v = -vMax; alpha = wrapToPi(alpha + pi); e = wrapToPi(alpha - q_from(3));
%                 end
%             case 'dubins'
%                 % Forward-only. If goal is behind (>90°), rotate in place to reduce |e|.
%                 if abs(e) > pi/2
%                     v = 0; omega = omegaMax * sign(e);
%                     t = (abs(e) - pi/2) / max(abs(omega), eps);
%                     if t <= 0, t = min(abs(e)/max(abs(omega),eps),  stepSize/max(vMax,eps)); end
%                 else
%                     v = vMax;
%                 end
%         end
%         if abs(v) > 0
%             omega = omegaMax * (e / (pi/2));   % saturating turn toward alpha
%             t = stepSize / max(abs(v),eps);    % advance a fixed arc length
%         else
%             % pure rotation time already set for Dubins when needed
%             if ~exist('t','var'), t = min(abs(e)/max(abs(omega),eps), 1.0); end
%         end
%     end

%     % Closed-form SE(2) propagation for constant (v, omega)
%     if abs(v) < 1e-6 && abs(omega) > 1e-6
%         % Pure rotation
%         q_new = [q_from(1:2); q_from(3)+omega*t];
%     elseif abs(omega) < 1e-6
%         % Straight
%         q_new = [q_from(1)+v*t*cos(q_from(3)); q_from(2)+v*t*sin(q_from(3)); q_from(3)];
%     else
%         % Circular arc with radius R = v/omega
%         q_new_theta = q_from(3)+omega*t;
%         q_new_x = q_from(1) + (v/omega)*(sin(q_new_theta)-sin(q_from(3)));
%         q_new_y = q_from(2) + (v/omega)*(cos(q_from(3))-cos(q_new_theta));
%         q_new = [q_new_x; q_new_y; q_new_theta];
%     end

%     % Discretize the motion for collision checking
%     isFree = true;
%     traj = zeros(3, numSteps+1); traj(:,1) = q_from;
%     for k = 1:numSteps
%         tk = k/numSteps * t;
%         if abs(v) < 1e-6 && abs(omega) > 1e-6
%             x = q_from(1); y = q_from(2); th = q_from(3)+omega*tk;
%         elseif abs(omega) < 1e-6
%             x = q_from(1)+v*tk*cos(q_from(3));
%             y = q_from(2)+v*tk*sin(q_from(3)); th = q_from(3);
%         else
%             th = q_from(3)+omega*tk;
%             x = q_from(1) + (v/omega)*(sin(th)-sin(q_from(3)));
%             y = q_from(2) + (v/omega)*(cos(q_from(3))-cos(th));
%         end
%         q_k = [x; y; th];
%         traj(:,k+1) = q_k;

%         if ~isConfigFree(q_k, A, obstacles, bounds, considerBounds)
%             isFree = false; q_new = []; traj = []; break;
%         end
%     end
% end

% ======================================================================
% Final approach & micro-snap (with shortest-angle rotations)
% ======================================================================

function [traj, ok] = finalApproach(q_from, q_goal, A, obstacles, bounds, considerBounds, nAng, nLine)
    % finalApproach
    % Deterministic finish inside the capture region:
    %   1) rotate to face the goal position,
    %   2) drive straight to that XY,
    %   3) rotate to the goal heading.
    traj = []; ok = false;

    % 1) rotate to face goal (shortest sweep)
    alpha = atan2(q_goal(2)-q_from(2), q_goal(1)-q_from(1));
    if ~rotateFree(q_from, alpha, A, obstacles, bounds, considerBounds, nAng), return; end
    seg1 = sampleRotation(q_from, alpha, nAng);

    % 2) straight to goal position
    if ~straightFree([q_from(1); q_from(2); alpha], q_goal(1:2), A, obstacles, bounds, considerBounds, nLine), return; end
    seg2 = sampleStraight([q_from(1); q_from(2); alpha], q_goal(1:2), nLine);

    % 3) rotate to goal orientation (shortest sweep)
    if ~rotateFree([q_goal(1); q_goal(2); alpha], q_goal(3), A, obstacles, bounds, considerBounds, nAng), return; end
    seg3 = sampleRotation([q_goal(1); q_goal(2); alpha], q_goal(3), nAng);

    traj = [seg1, seg2(:,2:end), seg3(:,2:end)];
    ok = true;
end

function [seg, ok] = microSnap(q_last, q_goal, A, obstacles, bounds, considerBounds, nAng, nLine)
    % microSnap
    % Tiny rotate→straight→rotate to land exactly at q_goal, if collision-free.
    seg = q_last; ok = false;

    alpha = atan2(q_goal(2)-q_last(2), q_goal(1)-q_last(1));
    if ~rotateFree(q_last, alpha, A, obstacles, bounds, considerBounds, nAng), return; end
    s1 = sampleRotation(q_last, alpha, nAng);

    if ~straightFree([q_last(1); q_last(2); alpha], q_goal(1:2), A, obstacles, bounds, considerBounds, nLine), return; end
    s2 = sampleStraight([q_last(1); q_last(2); alpha], q_goal(1:2), nLine);

    if ~rotateFree([q_goal(1); q_goal(2); alpha], q_goal(3), A, obstacles, bounds, considerBounds, nAng), return; end
    s3 = sampleRotation([q_goal(1); q_goal(2); alpha], q_goal(3), nAng);

    seg = [s1, s2(:,2:end), s3(:,2:end)];
    ok = true;
end

% ======================================================================
% Rotation & line segment validators/samplers
% ======================================================================

function thetas = shortestSweep(theta0, theta1, nSteps)
    % shortestSweep
    % Linear samples along the minimal signed angular difference in (-π, π].
    delta = wrapToPi(theta1 - theta0);
    thetas = theta0 + linspace(0, delta, nSteps);
end

function ok = rotateFree(q_from, theta_target, A, obstacles, bounds, considerBounds, nSteps)
    % rotateFree
    % Check if an in-place rotation from theta0 to theta_target is collision-free.
    thetas = shortestSweep(q_from(3), theta_target, nSteps);
    ok = true;
    for i=1:numel(thetas)
        if ~isConfigFree([q_from(1); q_from(2); thetas(i)], A, obstacles, bounds, considerBounds)
            ok = false; return;
        end
    end
end

function seg = sampleRotation(q_from, theta_target, nSteps)
    % sampleRotation
    % Produce a 3xN sequence of poses for an in-place rotation (no XY change).
    thetas = shortestSweep(q_from(3), theta_target, nSteps);
    seg = [repmat(q_from(1:2),1,numel(thetas)); thetas];
end

function ok = straightFree(q_from_aligned, xy_goal, A, obstacles, bounds, considerBounds, nSteps)
    % straightFree
    % Check if a straight segment at fixed heading is collision-free.
    xs = linspace(q_from_aligned(1), xy_goal(1), nSteps);
    ys = linspace(q_from_aligned(2), xy_goal(2), nSteps);
    th = q_from_aligned(3);
    ok = true;
    for i=1:nSteps
        if ~isConfigFree([xs(i); ys(i); th], A, obstacles, bounds, considerBounds)
            ok = false; return;
        end
    end
end

function seg = sampleStraight(q_from_aligned, xy_goal, nSteps)
    % sampleStraight
    % Produce a 3xN straight-line segment at a fixed heading.
    xs = linspace(q_from_aligned(1), xy_goal(1), nSteps);
    ys = linspace(q_from_aligned(2), xy_goal(2), nSteps);
    seg = [xs; ys; repmat(q_from_aligned(3),1,nSteps)];
end

% ======================================================================
% Collision check
% ======================================================================

function free = isConfigFree(q, A, obstacles, bounds, considerBounds)
    % isConfigFree
    % Transform robot footprint by SE(2) pose q and test:
    %   • inside boundary (vertex-inclusion) [optional], and
    %   • no polygon overlaps with obstacles.

    % Body-to-world transform (rotation + translation)
    R = [cos(q(3)), -sin(q(3)); sin(q(3)), cos(q(3))];
    A_trans = R*A + q(1:2);

    % Polygon for robot footprint at q
    robot_ps = polyshape(A_trans.', 'Simplify', false);

    % Boundary containment (fast vertex test is sufficient for convex bounds;
    % for nonconvex bounds this is still conservative and generally correct)
    if considerBounds
        if ~all(inpolygon(A_trans(1,:), A_trans(2,:), bounds(1,:), bounds(2,:)))
            free = false; return;
        end
    end

    % Obstacle overlap test
    for i = 1:numel(obstacles)
        if overlaps(robot_ps, obstacles{i})
            free = false; return;
        end
    end
    free = true;
end

% ======================================================================
% Angle wrap
% ======================================================================

function ang = wrapToPi(ang)
    % wrapToPi
    % Map any angle to (-π, π].
    ang = mod(ang + pi, 2*pi) - pi;
end

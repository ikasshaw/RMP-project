function [selID, nbrIDs] = inspectAdjacencies_linked(all_cells, FACE, varargin)
% Visual inspector for adjacencies when using linkAcrossParentFaces.
% Plots leaf cells, lets you select one from a list, and highlights its
% adjacent leaf neighbors across all 6 faces.
%
% Usage:
%   inspectAdjacencies_linked(all_cells, FACE)
%   inspectAdjacencies_linked(all_cells, FACE, 'onlyEmpty', true)
%   [selID, nbrIDs] = inspectAdjacencies_linked(...)
%
% Requirements:
%   - all_cells(i) has fields: id, xybounds(2x4), isLeaf, neigh(1x6),
%     parentID, children(1x8). If you saved child.indexInParent, we’ll use it;
%     otherwise we fall back to a small O(8) search.

p = inputParser;
addParameter(p,'onlyEmpty',false,@islogical);
parse(p,varargin{:});
onlyEmpty = p.Results.onlyEmpty;

faces = [FACE.XM FACE.XP FACE.YM FACE.YP FACE.TM FACE.TP];

% Collect leaf IDs
isLeaf = arrayfun(@(c)c.isLeaf, all_cells);
leafIDs = uint32(find(isLeaf));
if isempty(leafIDs), warning('No leaf cells to show.'); selID=[]; nbrIDs=[]; return; end

% Optionally restrict to empty leaves
if onlyEmpty
    emptyMask = false(size(leafIDs));
    for i=1:numel(leafIDs)
        v = all_cells(leafIDs(i)).cellIntersection;
        emptyMask(i) = (isa(v,'CellClass') && v==CellClass.Empty) || (ischar(v)||isstring(v) && string(v)=="Empty");
    end
    leafIDs = leafIDs(emptyMask);
    if isempty(leafIDs), warning('No empty leaves to show.'); selID=[]; nbrIDs=[]; return; end
end

% Plot all leaves
figure('Name','Adjacency Inspector (linked)'); clf; ax = axes; hold(ax,'on'); axis(ax,'equal');
baseFill = [0.85 0.85 0.85];
edgeCol = [0.3 0.3 0.3];
id2patch = containers.Map('KeyType','uint32','ValueType','any');
labels = strings(1,numel(leafIDs));
for i = 1:numel(leafIDs)
    id = leafIDs(i);
    R  = all_cells(id).xybounds; % 2x4
    h  = patch('XData',R(1,:),'YData',R(2,:),'FaceColor',baseFill,'EdgeColor',edgeCol, ...
               'LineWidth',0.5,'FaceAlpha',0.2,'Tag',sprintf('%u',id));
    id2patch(id) = h;
    if isfield(all_cells,'cx') && isfield(all_cells,'cy')
        labels(i) = sprintf('#%u  (%.3g, %.3g)', id, all_cells(id).cx, all_cells(id).cy);
    else
        labels(i) = sprintf('#%u', id);
    end
end
title(ax,'Pick a cell from the list to highlight its neighbors');

selID = uint32(0); nbrIDs = uint32([]);

while true
    [idx, ok] = listdlg('PromptString','Select a leaf cell', ...
                        'ListString',cellstr(labels), ...
                        'SelectionMode','single','ListSize',[300 400]);
    if ~ok, break; end
    selID = leafIDs(idx);

    % Reset all styles
    for i = 1:numel(leafIDs)
        h = id2patch(leafIDs(i));
        set(h,'FaceColor',baseFill,'EdgeColor',edgeCol,'LineWidth',0.5,'FaceAlpha',0.2);
    end
    % Highlight selected
    if isKey(id2patch, selID)
        set(id2patch(selID),'FaceColor',[0.2 0.4 1.0],'FaceAlpha',0.3,'EdgeColor',[0 0 0.8],'LineWidth',2.0);
    end

    % Resolve neighbors to *leaf* ids using neigh + descent if needed
    nbrIDs = uint32([]);
    for f = faces
        nid = all_cells(selID).neigh(f);
        if nid==0, continue; end
        % If nid is not a leaf, descend along the matching child index across this face
        if all_cells(nid).isLeaf
            leafNbr = nid;
        else
            k = getIndexInParent(all_cells, selID);            % 1..8
            nk = mapChildAcrossFace(k, f, FACE);               % 1..8 across face
            if nk==0, continue; end
            cur = nid;
            while all_cells(cur).isLeaf == false
                cur = all_cells(cur).children(nk);
                if cur==0, break; end
            end
            leafNbr = cur;
        end
        if leafNbr~=0
            nbrIDs(end+1) = leafNbr; %#ok<AGROW>
        end
    end
    nbrIDs = unique(nbrIDs);
    % If showing only empties, filter to those
    if onlyEmpty
        keep = false(size(nbrIDs));
        for j=1:numel(nbrIDs)
            v = all_cells(nbrIDs(j)).cellIntersection;
            keep(j) = (isa(v,'CellClass') && v==CellClass.Empty) || (ischar(v)||isstring(v) && string(v)=="Empty");
        end
        nbrIDs = nbrIDs(keep);
    end

    % Highlight neighbors
    for j = 1:numel(nbrIDs)
        id = nbrIDs(j);
        if isKey(id2patch, id)
            set(id2patch(id),'FaceColor',[1.0 0.8 0.1],'FaceAlpha',0.4,'EdgeColor',[0.75 0.5 0],'LineWidth',2.0);
        end
    end

    % Optional: draw centroid lines
    if isfield(all_cells,'cx') && isfield(all_cells,'cy')
        cx0 = all_cells(selID).cx; cy0 = all_cells(selID).cy;
        for j = 1:numel(nbrIDs)
            cx1 = all_cells(nbrIDs(j)).cx; cy1 = all_cells(nbrIDs(j)).cy;
            plot(ax,[cx0 cx1],[cy0 cy1],'-','Color',[0.25 0.25 0.25],'LineWidth',1.0);
        end
    end
    drawnow;
end

hold(ax,'off');
end

% ---------- helpers ----------

function k = getIndexInParent(all_cells, childID)
% Returns 1..8 index of childID in its parent's children.
    pid = all_cells(childID).parentID;
    if pid==0, k=0; return; end
    % Use stored index if you have it:
    if isfield(all_cells,'indexInParent') && ~isempty(all_cells(childID).indexInParent)
        k = double(all_cells(childID).indexInParent);
        return
    end
    kids = all_cells(pid).children;
    k = find(kids==childID, 1, 'first');
    if isempty(k), k = 0; end
end

function nk = mapChildAcrossFace(k, face, FACE)
% Maps child index k (1..8) to the opposite-face child index in the neighbor.
    persistent mapXM mapXP mapYM mapYP mapTM mapTP
    if isempty(mapXM)
        mapXM = [2 0 4 0 6 0 8 0];
        mapXP = [0 1 0 3 0 5 0 7];
        mapYM = [3 4 0 0 7 8 0 0];
        mapYP = [0 0 1 2 0 0 5 6];
        mapTM = [5 6 7 8 0 0 0 0];
        mapTP = [0 0 0 0 1 2 3 4];
    end
    switch face
        case FACE.XM, nk = mapXM(k);
        case FACE.XP, nk = mapXP(k);
        case FACE.YM, nk = mapYM(k);
        case FACE.YP, nk = mapYP(k);
        case FACE.TM, nk = mapTM(k);
        otherwise,     nk = mapTP(k);
    end
end

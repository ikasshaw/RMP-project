classdef HitType < int32
    enumeration
        none (0)
        goal (1)
        obstacle (2)
        boundary (3)
    end
end
classdef CellClass < int32
    enumeration
        Empty (0)
        Mixed (1)
        Full  (2)
    end
end

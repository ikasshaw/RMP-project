classdef RayType < int32
    enumeration
        initial (0)
        goal (1)
        reflection (2)
        random (3)
    end
end
% Isaac Shaw
% Robot Motion Planning
% 8/10/2025

function qpath = rayCastPlanner(A, q_init, q_goal, B, bounds, options)

    arguments
        A (2,:) double
        q_init (3,1) double
        q_goal (3,1) double
        B cell
        bounds (2,:) double

        options.debug logical = false
        options.initialRays (1,1) double = 5
        options.childrenPerBounce (1,1) double {mustBeInteger,mustBeGreaterThanOrEqual(options.childrenPerBounce,3)} = 5
        options.maxBounces (1,1) double {mustBeInteger,mustBeNonnegative} = 5
        options.maxIter (1,1) double = 500

        options.goalRegionNRays (1,1) double = 360
        options.goalRegionMargin (1,1) double = 1e-3
        options.goalThetaTol (1,1) double = deg2rad(10)
        options.includeReflection logical = true
        options.considerBounds logical = true
        options.turnCheckSteps (1,1) double {mustBeInteger,mustBePositive} = 12
        options.rngSeed (1,1) double = 1

        options.goalAngleSteps (1,1) double = 36
        options.goalLineSteps (1,1) double = 50

        options.debugCObs logical = true      % plot C-obstacles for current theta
        options.debugStep logical = true      % pause at each hit
        options.debugPause (1,1) double = 0   % if >0, pause(seconds)
        options.OnlyCurrentHitRay logical = false % only plot the current hit ray

        options.margin (1,1) double = 1e-3    % small safety padding
    end

    % --- Input checks ---
    checkQ(q_init); checkQ(q_goal);
    checkVertices(A); checkVertices(bounds);
    if ~inpolygon(q_init(1), q_init(2), bounds(1,:), bounds(2,:)) || ...
       ~inpolygon(q_goal(1), q_goal(2), bounds(1,:), bounds(2,:))
        error('All points must be inside the boundary');
    end
    for i = 1:numel(B)
        checkVertices(B{i});
        if ~all(inpolygon(B{i}(1,:), B{i}(2,:), bounds(1,:), bounds(2,:)))
            error('All obstacle vertices must be inside the boundary');
        end
    end

    obstacles = cell(1, numel(B));
    for i = 1:numel(B), obstacles{i} = polyshape(B{i}.', 'Simplify', false); end
    boundsPS = polyshape(bounds.', 'Simplify', false);

    rng(options.rngSeed);

    R_robot = max(sqrt(sum(A.^2,1)));

    d_ray = radialClearance(q_goal(1:2), obstacles, bounds, options.goalRegionNRays);
    r_cap = max(0, d_ray - (R_robot + options.goalRegionMargin));

    % Debug plotting
    if options.debug
        if isempty(groot().Children), figure('Name','rayCastPlanner - DEBUG'); end
        plot(boundsPS, 'FaceColor','none','EdgeColor','k');
        [finit, ~] = plotRobot(q_init, A, 'world', true);
        [fgoal, ~] = plotRobot(q_goal, A, 'world', true);
        set(finit, 'Parent', hgtransform('Matrix', Tz(q_init(3))));
        set(fgoal, 'Parent', hgtransform('Matrix', Tz(q_goal(3))));
        for i=1:numel(B), plotObstacle(B{i}, i); end
        plot(q_init(1), q_init(2), 'dg', 'MarkerSize',10, 'LineWidth',2);
        plot(q_goal(1), q_goal(2), 'dr', 'MarkerSize',10, 'LineWidth',2);
        if r_cap > 0
            th = linspace(0,2*pi,200);
            plot(q_goal(1)+r_cap*cos(th), q_goal(2)+r_cap*sin(th), 'm--', 'LineWidth',1.5);
        end
        drawnow;
    end

    StackItem = @(p,th,b,segs,rtype,htype) struct('p',p,'th',th,'b',b,'segs',segs, 'rayType', rtype, 'hitType', htype);

    % --- Initial ray set (DFS) ---
    th0 = wrapToPi(q_init(3));
    th_goal = wrapToPi(atan2(q_goal(2) - q_init(2), q_goal(1) - q_init(1)));
    dirs = [sampleDirections(th0, max(0, options.initialRays - 1)), th_goal];
    stack = StackItem(q_init(1:2),th0,0, q_init, RayType.initial, HitType.none);

    for i = 2:numel(dirs)
        stack(end+1) = StackItem(q_init(1:2), dirs(i), 0, q_init, RayType.initial, HitType.none);
    end

    successPaths = {};
    iters = 0;

    while ~isempty(stack) && iters < options.maxIter
        node  = stack(end); stack(end) = [];     % LIFO → DFS
        iters = iters + 1;

        if options.debug
            if numel(stack) == 0
                disp("Stack is empty, terminating...")
                break;
            end
        end

        if options.debug,
            if node.rayType == RayType.initial
                disp("Processing initial ray");
            else
                % disp("Processing child ray");
                % disp("Ray type: " + string(node.rayType));
                disp("Processing child with RayType " + string(node.rayType) + " at " + ...
                     "p = [" + num2str(node.p(1),3) + ", " + num2str(node.p(2),3) + "], " + ...
                     "th = " + num2str(node.th,3) + ", b = " + string(node.b));
            end
            delete(findall(gca, 'Tag','HitPoint'));
            delete(findall(gca, 'Tag','HitNormal'));
            delete(findall(gca, 'Tag','HitRay'));
            delete(findall(gca, 'Tag','BacktrackRay'));
            delete(findall(gca, 'Tag','ParentPath'));
        end

        p     = node.p;
        th    = wrapToPi(node.th);
        b     = node.b;
        segs  = node.segs;

        if options.debug
            for i = 1:(size(segs, 2)-1)
                plot(segs(1, i:i+1), segs(2,i:i+1), 'm-', 'LineWidth', 1.5, 'Tag', 'ParentPath');
            end
        end

        while b <= options.maxBounces
            % Optional: C-space overlay for this theta
            if options.debug && options.debugCObs
                delete(findall(gca, 'Tag','CObs')); delete(findall(gca,'Tag','CObsLabel'));
                cObs = cell(1,numel(B));
                for i = 1:numel(B), cObs{i} = cObstacle(th, A, B{i}); end
                debugPlotCspaceAtTheta(cObs); drawnow;
            else
                cObs = {};
                for i = 1:numel(B), cObs{i} = obstacles{i}; end % fall back to workspace polys
            end

            % Exact first event
            [hitType, hitPoint, segRay, hitNormal] = castRay(p, th, cObs, bounds, q_goal, r_cap);

            if ~isempty(segRay)
                if options.debug

                    disp("Hit type: " + string(hitType));

                    clr = 'c-';
                    lw = 1;
                    if hitType == HitType.goal
                        clr = 'g-';
                        lw = 2;
                    elseif hitType == HitType.boundary
                        clr = 'b-';
                        lw = 1.5;
                    end

                    if options.OnlyCurrentHitRay
                        delete(findall(gca,'Tag','HitRay'));
                    end

                    plot(segRay(1,:), segRay(2,:), clr, 'LineWidth', lw, 'Tag','HitRay');

                    drawnow;
                end

            end

            % Pause on intersection
            if options.debug && options.debugStep && (hitType == HitType.obstacle || hitType == HitType.boundary)
                plot(hitPoint(1), hitPoint(2), 'ro', 'MarkerSize',6, 'LineWidth',1.5, 'Tag', 'HitPoint');
                if ~isempty(hitNormal)
                    L=0.6; quiver(hitPoint(1), hitPoint(2), hitNormal(1)*L, hitNormal(2)*L, 0, 'Color',[0.5 0 0.7], 'LineWidth',1, 'Tag', 'HitNormal');
                end
                drawnow;
                debugStepBlock(options.debugStep, options.debugPause);
            end

            if hitType == HitType.goal
                disp("Ray reached goal region");
                segs = [segs, [hitPoint(1); hitPoint(2); th], q_goal];
                if options.debug
                    plot(hitPoint(1), hitPoint(2), 'ro', 'MarkerSize',6, 'LineWidth',1.5);
                    for i = 1:(size(segs, 2)-1)
                        plot(segs(1, i:i+1), segs(2,i:i+1), 'g-', 'LineWidth', 1.5, 'Tag', 'GoalPath');
                    end

                end
                successPaths{end+1} = segs;
                % qpoly = segsToPolyline(segs, th);
                % [snapSeg, ok] = microSnap(qpoly(:,end), q_goal, A, obstacles, bounds, ...
                %                           options.considerBounds, ...
                %                           max(12, options.goalAngleSteps), max(25, options.goalLineSteps));
                % if ok
                %     qpoly = [qpoly, snapSeg(:,2:end)];
                % else
                %     if abs(wrapToPi(qpoly(3,end)-q_goal(3))) <= options.goalThetaTol
                %         qpoly(:,end) = q_goal;
                %     end
                % end
                % successPaths{end+1} = qpoly; %#ok<AGROW>
                break; % terminate this ray
            end

            % --- Generate children headings ---
            childData = genChildren(hitType,...
                                    th,...
                                    hitNormal,...
                                    hitPoint,...
                                    q_goal,...
                                    options.childrenPerBounce,...
                                    options.includeReflection,...
                                    R_robot,...
                                    A,...
                                    obstacles,...
                                    bounds,...
                                    options.considerBounds);

            if isempty(childData)
                break
            end
            
            % DFS: take first child now (goal ray if available), push the rest
            for i = numel(childData):-1:2
                segs_i = [segs, [childData(i).p_emit; childData(i).th]];
                % segs_i = [segs, childData(i).backSeg(:,2)];
                stack(end+1) = StackItem(childData(i).p_emit, childData(i).th, b+1, segs_i, childData(i).rayType, childData(i).hitType);
            end
            % Follow first child immediately
            segs = [segs, [childData(1).p_emit; childData(1).th]];
            if options.debug
                plot(childData(1).backSeg(1,:), childData(1).backSeg(2,:), 'r-', 'LineWidth',1, 'Tag', 'BacktrackRay');
            end
            p  = childData(1).p_emit;
            th = childData(1).th;
            b  = b + 1;
            drawnow;
        end
    end
    successPaths
    for i = 1:numel(successPaths)
        if options.debug
            disp("Success path " + i + ":");
            disp(successPaths{i});
        end
    end

    if isempty(successPaths)
        qpath = []; return;
    end

    % --- Graph stitching (your steps 3–5) ---
    segments = zeros(0,4);
    for i = 1:numel(successPaths)
        segments = [segments; polylineToSegments(successPaths{i})]; %#ok<AGROW>
    end
    [nodes, edges] = segmentsToGraph(segments);
    nodes = [nodes; q_init(1:2).'; q_goal(1:2).'];
    [nodes, idmap] = mergeCloseNodes(nodes, 1e-8);
    sID = idmap(size(nodes,1)-1); gID = idmap(size(nodes,1));
    Ed = finalizeEdges(edges, nodes);
    G = graph(Ed(:,1), Ed(:,2), Ed(:,3));
    if sID<1 || sID>numnodes(G) || gID<1 || gID>numnodes(G), qpath=[]; return; end
    [pth, ~] = shortestpath(G, sID, gID, 'Method','positive');
    if isempty(pth), qpath = []; return; end

    XY = nodes(pth,:).';
    qpoly = discretizePolyline(XY);
    [seg_snap, ok_snap] = microSnap(qpoly(:,end), q_goal, A, obstacles, bounds, options.considerBounds, ...
                                    max(12, options.goalAngleSteps), max(25, options.goalLineSteps));
    if ok_snap, qpoly = [qpoly, seg_snap(:,2:end)]; end
    qpoly(:,1) = q_init; qpoly(:,end) = q_goal;
    qpath = qpoly;
end

% -------------------- Children generator (goal + reflection + randoms) --------------------
function childData = genChildren(hit_type,...
                                 th_in,...
                                 n_hat,...
                                 parent_hit_point,...
                                 q_goal,...
                                 nChildren,...
                                 includeReflection,...
                                 R_robot,...
                                 A,...
                                 obstacles,...
                                 bounds,...
                                 considerBounds)

    % disp("Generating children at hit point");
    % For each child, compute a per-child safe emit point (backtrack along ray)
    u_ray = [cos(th_in); sin(th_in)];   % incident ray direction

    childData = struct('th',{},'p_emit',{},'backSeg',{}, 'rayType',{}, 'hitType',{});

    % Get goal child
    [p_emit, backSeg, th] = computeSafeEmitBacktrack(parent_hit_point, u_ray, th_in, A, obstacles, bounds, considerBounds, R_robot, q_goal, RayType.goal, n_hat);

    if ~isempty(p_emit) && ~ isempty(backSeg) && abs(wrapToPi(th - th_in)) > 1e-3
        childData(end+1).th = th;
        childData(end).p_emit = p_emit;
        childData(end).backSeg = backSeg;
        childData(end).rayType = RayType.goal;
        childData(end).hitType = hit_type;
    end

    % Get reflection child
    if includeReflection && ~isempty(n_hat)
        [p_emit, backSeg, th] = computeSafeEmitBacktrack(parent_hit_point, u_ray, th_in, A, obstacles, bounds, considerBounds, R_robot, q_goal, RayType.reflection, n_hat);

        if ~isempty(p_emit) && ~ isempty(backSeg) && abs(wrapToPi(th - th_in)) > 1e-3
            childData(end+1).th = th;
            childData(end).p_emit = p_emit;
            childData(end).backSeg = backSeg;
            childData(end).rayType = RayType.reflection;
            childData(end).hitType = hit_type;
        end
    end

    % Get random children
    nRand = max(0, nChildren - numel(childData));
    if nRand > 0
        for i=1:nRand
            [p_emit, backSeg, th] = computeSafeEmitBacktrack(parent_hit_point, u_ray, th_in, A, obstacles, bounds, considerBounds, R_robot, q_goal, RayType.random, n_hat);
            if ~isempty(p_emit) && ~ isempty(backSeg) && abs(wrapToPi(th - th_in)) > 1e-3
                childData(end+1).th = th;
                childData(end).p_emit = p_emit;
                childData(end).backSeg = backSeg;
                childData(end).rayType = RayType.random;
                childData(end).hitType = hit_type;
            end
        end
    end

end


function [p_emit, backSeg, th_try] = computeSafeEmitBacktrack(hitPoint, u_ray, th_cur, A, obstacles,...
                                                                bounds, considerBounds, R_robot, q_goal, angleType, n_hat)

% Backtrack along the *incoming* ray by a distance that guarantees:
%   1) robot at p_emit with heading th_cur is collision-free, and
%   2) rotating th_cur -> th_child is collision-free (rotateFree)
% Works for both obstacle and boundary hits.

    p_emit = []; backSeg = []; th_try = [];

    u = u_ray / max(norm(u_ray), eps);
    moveDir = -u;  % back along the ray (away from the contact)

    % Start slightly larger than radius; grow until safe
    d0 = max(1e-3, 1.1*R_robot);
    scales = [1 1.5 2 3 4];

    for s = scales
        d = d0 * s;
        p_emit = hitPoint + d * moveDir;

        if angleType == RayType.goal
            th_try = atan2(q_goal(2)-p_emit(2), q_goal(1)-p_emit(1));
        elseif angleType == RayType.reflection
            th_try = reflectAngle(th_cur, n_hat);
        else
            th_try = wrapToPi(th_cur + 2*pi*rand);
        end

        if considerBounds && ~inpolygon(p_emit(1), p_emit(2), bounds(1,:), bounds(2,:))
            return
        end

        % robot at p_emit with current heading must be free
        if ~isConfigFree([p_emit; th_cur], A, obstacles, bounds, considerBounds)
            return
        end

        % and rotation to child heading must also be free
        if ~rotateFree([p_emit; th_cur], th_try, A, obstacles, bounds, considerBounds, 36)
            return
        end

        % success
        backSeg = [hitPoint, p_emit];
        return;
    end
end

% -------------------- Core ray: exact first event --------------------
function [hitType, hitP, seg, n_hat] = castRay(p0, th, cObstacles, bounds, q_goal, r_cap)
    u = [cos(th); sin(th)];
    seg = []; hitType=HitType.none; hitP=[]; n_hat=[];

    % Goal circle
    if r_cap > 0
        [~, gP, tG] = rayCircleIntersect(p0, u, q_goal(1:2), r_cap);
    else
        gP = []; tG = inf;
    end

    % Obstacles (C-obs for this theta if provided; else workspace polys)
    [tO, pO, nO] = rayFirstHitWithcObstacles(p0, u, cObstacles);

    % World boundary
    [tB, pB, nB] = rayFirstHitWithBounds(p0, u, bounds);

    [tmin, idx] = min([tG, tO, tB, inf]);
    if isinf(tmin) || isnan(tmin), return; end

    switch idx
        case 1, hitType=HitType.goal;     hitP=gP; n_hat=[];
        case 2, hitType=HitType.obstacle; hitP=pO; n_hat=nO;
        case 3, hitType=HitType.boundary; hitP=pB; n_hat=nB;
    end
    seg = [p0, hitP];
end

% -------------------- Exact intersection helpers --------------------
function [tf, P, t] = rayCircleIntersect(p0, dir, c, r, tol)
    if nargin < 5, tol = 1e-12; end
    dp = p0 - c;
    a  = dot(dir, dir);
    b  = 2*dot(dir, dp);
    c2 = dot(dp, dp) - r^2;
    disc = b*b - 4*a*c2;
    if disc < 0, tf=false; P=[]; t=inf; return; end
    s  = sqrt(max(disc,0));
    t1 = (-b - s)/(2*a);
    t2 = (-b + s)/(2*a);
    ts = [t1, t2]; ts = ts(ts > tol);
    if isempty(ts), tf=false; P=[]; t=inf; return; end
    t = min(ts);
    P = p0 + t*dir;
    tf = true;
end

function [tmin, Pmin, n_hat] = rayFirstHitWithcObstacles(p0, u, cObstacles)
    tmin = inf; Pmin = [NaN;NaN]; n_hat = [0;0];
    for k = 1:numel(cObstacles)
        Ck = cObstacles{k};
        if isa(Ck, 'polyshape')
            R = regions(Ck);
            for r = 1:numel(R)
                V = R(r).Vertices; if size(V,1) < 2, continue; end
                if any(V(1,:)~=V(end,:)), V = [V; V(1,:)]; end
                for i = 1:size(V,1)-1
                    a = V(i,:).'; b = V(i+1,:).';
                    t = raySegIntersectDist(p0, u, a, b);
                    if ~isnan(t) && t > 1e-12 && t < tmin
                        tmin = t; Pmin = p0 + t*u;
                        e = b - a; n = [-e(2); e(1)];
                        n_hat = n / max(norm(n), eps);
                    end
                end
            end
        else
            % assume 2xK vertex array
            V = Ck; K = size(V,2);
            for i = 1:K
                a = V(:,i); b = V(:,mod(i,K)+1);
                t = raySegIntersectDist(p0, u, a, b);
                if ~isnan(t) && t > 1e-12 && t < tmin
                    tmin = t; Pmin = p0 + t*u;
                    e = b - a; n = [-e(2); e(1)];
                    n_hat = n / max(norm(n), eps);
                end
            end
        end
    end
end

function [tmin, Pmin, n_hat] = rayFirstHitWithBounds(p0, u, bounds)
    tmin = inf; Pmin = [NaN; NaN]; n_hat = [0;0];
    V = bounds; K = size(V,2);
    for i = 1:K
        a = V(:,i); b = V(:,mod(i,K)+1);
        t = raySegIntersectDist(p0, u, a, b);
        if ~isnan(t) && t > 1e-12 && t < tmin
            tmin = t;
            Pmin = p0 + t*u;
            e = b - a; n = [-e(2); e(1)]; % CCW bounds → outward
            n_hat = n / max(norm(n), eps);
        end
    end
end

% -------------------- Geometry helpers --------------------
function ths = sampleDirections(th0, n)
    if n <= 0, ths = []; return; end
    ths = wrapToPi(th0 + (2*pi)*rand(1,n));
end

function qpoly = segsToPolyline(segs, th)
    if isempty(segs), qpoly = []; return; end
    XY = [segs(1,1:2).', segs(:,3:4).'];   % stitch end points
    ths = th * ones(1, size(XY,2));
    qpoly = [XY; ths];
end

function S = polylineToSegments(Q)
    if size(Q,2) < 2, S = []; return; end
    S = [Q(1,1:end-1).', Q(2,1:end-1).', Q(1,2:end).', Q(2,2:end).'];
end

function [nodes, edges] = segmentsToGraph(S)
    nodes = [S(:,1:2); S(:,3:4)];
    edges = S;
    M = size(S,1);
    for i = 1:M
        for j = i+1:M
            [hit, P] = segSegIntersection(S(i,1:2), S(i,3:4), S(j,1:2), S(j,3:4));
            if hit, nodes = [nodes; P.']; end %#ok<AGROW>
        end
    end
end

function [hit, P] = segSegIntersection(a1, a2, b1, b2)
    a1 = a1(:); a2 = a2(:); b1 = b1(:); b2 = b2(:);
    da = a2 - a1; db = b2 - b1; dp = a1 - b1;
    M = [da, -db];
    if abs(det(M)) < 1e-12, hit=false; P=[NaN;NaN]; return; end
    x = M\dp; ua = -x(1); ub = -x(2);
    if ua>=0 && ua<=1 && ub>=0 && ub<=1
        P = a1 + ua*da; hit=true;
    else
        P = [NaN;NaN]; hit=false;
    end
end

function [nodes2, idmap] = mergeCloseNodes(nodes, tol)
    [nodes2, ~, ic] = uniquetol(nodes, tol, 'ByRows', true);
    idmap = ic;
end

function Ed = finalizeEdges(S, nodes)
    N = size(S,1);
    Ed = zeros(N,3);
    for i=1:N
        p = S(i,1:2); q = S(i,3:4);
        [~, idp] = min(sum((nodes - p).^2, 2));
        [~, idq] = min(sum((nodes - q).^2, 2));
        w = norm(q - p);
        if idp~=idq && isfinite(w) && w>0
            Ed(i,:) = [idp, idq, w];
        end
    end
    Ed = Ed(any(Ed,2),:);
end

function th_r = reflectAngle(th_incident, n_hat)
    v = [cos(th_incident); sin(th_incident)];
    n = n_hat / max(norm(n_hat), eps);
    v_r = v - 2*(v.'*n)*n;
    th_r = atan2(v_r(2), v_r(1));
end

function Q = discretizePolyline(XY)
    if size(XY,2) < 2, Q = [XY; 0]; return; end
    pts = [];
    for k=1:size(XY,2)-1
        p0 = XY(:,k); p1 = XY(:,k+1);
        L = norm(p1 - p0); n = max(2, ceil(L/0.25));
        t = linspace(0,1,n);
        seg = p0 + (p1 - p0).*t;
        th = atan2(p1(2)-p0(2), p1(1)-p0(1));
        pts = [pts, [seg; th*ones(1,n)]]; %#ok<AGROW>
    end
    Q = pts;
end

% -------------------- RRT helpers reused (verbatim) --------------------
function dmin = radialClearance(p, obstacles, bounds, nRays)
    phis = linspace(0, 2*pi, nRays+1); phis(end) = [];
    dmin = inf;
    polys = [obstacles, {polyshape(bounds.', 'Simplify', false)}];
    for phi = phis
        u = [cos(phi); sin(phi)];
        d_ray = inf;
        for k = 1:numel(polys)
            V = polys{k}.Vertices.'; % 2xK
            K = size(V,2);
            for i = 1:K
                a = V(:,i);
                b = V(:,mod(i,K)+1);
                t = raySegIntersectDist(p, u, a, b);
                if ~isnan(t)
                    d_ray = min(d_ray, t);
                end
            end
        end
        dmin = min(dmin, d_ray);
    end
    if isinf(dmin), dmin = 0; end
end

function t = raySegIntersectDist(p, u, a, b)
    v = b - a;
    M = [u, -v];
    rhs = a - p;
    detM = u(1)*(-v(2)) - u(2)*(-v(1));
    if abs(detM) < 1e-12, t = NaN; return; end
    sol = M \ rhs;  t = sol(1); s = sol(2);
    if t >= 0 && s >= 0 && s <= 1
        if t < 1e-12, t = NaN; end
    else
        t = NaN;
    end
end

function [traj, ok] = finalApproach(q_from, q_goal, A, obstacles, bounds, considerBounds, nAng, nLine)
    traj = []; ok = false;
    alpha = atan2(q_goal(2)-q_from(2), q_goal(1)-q_from(1));
    if ~rotateFree(q_from, alpha, A, obstacles, bounds, considerBounds, nAng), return; end
    seg1 = sampleRotation(q_from, alpha, nAng);
    if ~straightFree([q_from(1); q_from(2); alpha], q_goal(1:2), A, obstacles, bounds, considerBounds, nLine), return; end
    seg2 = sampleStraight([q_from(1); q_from(2); alpha], q_goal(1:2), nLine);
    if ~rotateFree([q_goal(1); q_goal(2); alpha], q_goal(3), A, obstacles, bounds, considerBounds, nAng), return; end
    seg3 = sampleRotation([q_goal(1); q_goal(2); alpha], q_goal(3), nAng);
    traj = [seg1, seg2(:,2:end), seg3(:,2:end)];
    ok = true;
end

function [seg, ok] = microSnap(q_last, q_goal, A, obstacles, bounds, considerBounds, nAng, nLine)
    seg = q_last; ok = false;
    alpha = atan2(q_goal(2)-q_last(2), q_goal(1)-q_last(1));
    if ~rotateFree(q_last, alpha, A, obstacles, bounds, considerBounds, nAng), return; end
    s1 = sampleRotation(q_last, alpha, nAng);
    if ~straightFree([q_last(1); q_last(2); alpha], q_goal(1:2), A, obstacles, bounds, considerBounds, nLine), return; end
    s2 = sampleStraight([q_last(1); q_last(2); alpha], q_goal(1:2), A, obstacles, bounds, considerBounds, nLine);
    if ~rotateFree([q_goal(1); q_goal(2); alpha], q_goal(3), A, obstacles, bounds, considerBounds, nAng), return; end
    s3 = sampleRotation([q_goal(1); q_goal(2); alpha], q_goal(3), nAng);
    seg = [s1, s2(:,2:end), s3(:,2:end)];
    ok = true;
end

function ok = rotateFree(q_from, theta_target, A, obstacles, bounds, considerBounds, nSteps)
    thetas = shortestSweep(q_from(3), theta_target, nSteps);
    ok = true;
    for i=1:numel(thetas)
        if ~isConfigFree([q_from(1); q_from(2); thetas(i)], A, obstacles, bounds, considerBounds)
            ok = false; return;
        end
    end
end

function thetas = shortestSweep(theta0, theta1, nSteps)
    delta = wrapToPi(theta1 - theta0);
    thetas = theta0 + linspace(0, delta, nSteps);
end

function seg = sampleRotation(q_from, theta_target, nSteps)
    thetas = shortestSweep(q_from(3), theta_target, nSteps);
    seg = [repmat(q_from(1:2),1,numel(thetas)); thetas];
end

function ok = straightFree(q_from_aligned, xy_goal, A, obstacles, bounds, considerBounds, nSteps)
    xs = linspace(q_from_aligned(1), xy_goal(1), nSteps);
    ys = linspace(q_from_aligned(2), xy_goal(2), nSteps);
    th = q_from_aligned(3);
    ok = true;
    for i=1:nSteps
        if ~isConfigFree([xs(i); ys(i); th], A, obstacles, bounds, considerBounds)
            ok = false; return;
        end
    end
end

function seg = sampleStraight(q_from_aligned, xy_goal, ~, ~, ~, ~, ~)
    % Overload signature to keep compatibility with call above
    % (xy only; ignore extra args if passed)
    xs = linspace(q_from_aligned(1), xy_goal(1), 50);
    ys = linspace(q_from_aligned(2), xy_goal(2), 50);
    seg = [xs; ys; repmat(q_from_aligned(3),1,50)];
end

function free = isConfigFree(q, A, obstacles, bounds, considerBounds)
    R = [cos(q(3)), -sin(q(3)); sin(q(3)), cos(q(3))];
    A_trans = R*A + q(1:2);
    robot_ps = polyshape(A_trans.', 'Simplify', false);

    if considerBounds
        if ~all(inpolygon(A_trans(1,:), A_trans(2,:), bounds(1,:), bounds(2,:)))
            free = false; return;
        end
    end
    for i = 1:numel(obstacles)
        if overlaps(robot_ps, obstacles{i})
            free = false; return;
        end
    end
    free = true;
end

function ang = wrapToPi(ang)
    ang = mod(ang + pi, 2*pi) - pi;
end

% ---------- Tiny input guards ----------
function checkQ(q)
    if ~isfloat(q) || numel(q)~=3
        error('q must be 3x1 [x;y;theta]');
    end
end

function checkVertices(V)
    if ~isfloat(V) || size(V,1)~=2 || size(V,2)<3
        error('Polygon must be 2xK, K>=3');
    end
end

% ---------- Debug C-obstacle overlay ----------
function debugPlotCspaceAtTheta(cObstacles)
    for i = 1:numel(cObstacles)
        C = cObstacles{i};
        [ph, lbl] = plotCObstacle(C, i); %#ok<NASGU>
        set(ph,  'Tag','CObs', 'HitTest','off');
        set(lbl, 'Tag','CObsLabel', 'HitTest','off');
    end
end

function debugStepBlock(doStep, pauseSec)
    if ~doStep, return; end
    if pauseSec > 0
        pause(pauseSec);
    else
        title('Collision: press any key / click to continue'); drawnow;
        waitforbuttonpress;
    end
end

Steps

1. Given the parents adjacencies:
   1. for each subdivision
      1. for each sibling
         1. Check if adjancent above, below, left, right
      2. for each parent adjacency
         1. Check if adjacent above, below, left, right
            1. in check, if parent is not a leaf, check all children